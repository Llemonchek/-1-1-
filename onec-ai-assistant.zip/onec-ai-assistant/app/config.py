"""Настройки приложения. Всё переопределяется переменными окружения."""
from __future__ import annotations

import os
import shlex
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Папка с выгрузкой конфигурации 1С (файлы .bsl ищутся рекурсивно)
CONFIG_DIR = Path(os.getenv("ONEC_CONFIG_DIR", ROOT / "1c_config"))
DATA_DIR = Path(os.getenv("DATA_DIR", ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Локальная модель через Ollama
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434").rstrip("/")
MODEL = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:3b")
NUM_CTX = int(os.getenv("NUM_CTX", "8192"))  # контекстное окно модели, токенов

# Бюджет контекста для вопроса, символов (модель 3B плохо переносит длинные промпты)
CONTEXT_CHARS = int(os.getenv("CONTEXT_CHARS", "7000"))

# BSL Language Server: путь к jar-файлу или полная команда запуска
BSL_LS_JAR = os.getenv("BSL_LS_JAR", "")
BSL_LS_CMD = os.getenv("BSL_LS_CMD", "")  # например: "bsl-language-server" или "java -Xmx2g -jar x.jar"
BSL_LS_TIMEOUT = int(os.getenv("BSL_LS_TIMEOUT", "60"))

SKIP_DIRS = {".git", ".idea", ".vscode", "node_modules", "__pycache__", ".venv", "venv"}

# Автоматическая проверка папки с выгрузкой (секунды) и учётные записи
SCAN_INTERVAL = max(1, int(os.getenv("SCAN_INTERVAL", "5")))
AUTO_SCAN = os.getenv("AUTO_SCAN", "1") != "0"
REQUIRE_LOGIN = os.getenv("REQUIRE_LOGIN", "0") == "1"  # 1: задавать вопросы могут только вошедшие
SESSION_HOURS = int(os.getenv("SESSION_HOURS", "12"))

GRAPH_FILE = DATA_DIR / "graph.json"
USERS_FILE = DATA_DIR / "users.json"
SECRET_FILE = DATA_DIR / "secret.key"
SUMMARIES_FILE = DATA_DIR / "summaries.json"
FEEDBACK_FILE = DATA_DIR / "feedback.jsonl"


def bsl_ls_command() -> list[str] | None:
    """Команда запуска BSL Language Server или None, если он не настроен."""
    if BSL_LS_CMD:
        return shlex.split(BSL_LS_CMD)
    if BSL_LS_JAR:
        return ["java", "-jar", BSL_LS_JAR]
    return None
