"""Минимальный LSP-клиент для BSL Language Server (общение по stdio).

Используется один запрос: textDocument/documentSymbol, который возвращает
процедуры и функции модуля вместе с границами в файле.
"""
from __future__ import annotations

import itertools
import json
import queue
import subprocess
import threading
from pathlib import Path

SYMBOL_METHOD, SYMBOL_FUNCTION = 6, 12


class BslLanguageServer:
    def __init__(self, cmd: list[str], root: Path, timeout: int = 60):
        self.cmd = cmd
        self.root = Path(root).resolve()
        self.timeout = timeout
        self.proc: subprocess.Popen | None = None
        self._ids = itertools.count(1)
        self._pending: dict[int, queue.Queue] = {}
        self._write_lock = threading.Lock()

    # ---- жизненный цикл -------------------------------------------------
    def start(self) -> None:
        self.proc = subprocess.Popen(
            self.cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
        )
        threading.Thread(target=self._reader, daemon=True).start()
        self.request(
            "initialize",
            {
                "processId": None,
                "rootUri": self.root.as_uri(),
                "capabilities": {
                    "textDocument": {"documentSymbol": {"hierarchicalDocumentSymbolSupport": True}}
                },
            },
            timeout=180,  # старт JVM и индексация могут быть долгими
        )
        self.notify("initialized", {})

    def close(self) -> None:
        if not self.proc:
            return
        try:
            self.request("shutdown", None, timeout=5)
            self.notify("exit", None)
        except Exception:
            pass
        try:
            self.proc.terminate()
        except Exception:
            pass
        self.proc = None

    # ---- публичный API --------------------------------------------------
    def document_symbols(self, path: Path, text: str) -> list[tuple[str, int, int]]:
        """Возвращает [(имя, первая_строка, последняя_строка)] процедур и функций модуля."""
        uri = Path(path).resolve().as_uri()
        self.notify(
            "textDocument/didOpen",
            {"textDocument": {"uri": uri, "languageId": "bsl", "version": 1, "text": text}},
        )
        try:
            result = self.request("textDocument/documentSymbol", {"textDocument": {"uri": uri}})
        finally:
            self.notify("textDocument/didClose", {"textDocument": {"uri": uri}})
        return list(flatten_symbols(result or []))

    # ---- транспорт JSON-RPC ---------------------------------------------
    def request(self, method: str, params, timeout: int | None = None):
        rid = next(self._ids)
        q: queue.Queue = queue.Queue(1)
        self._pending[rid] = q
        self._send({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
        try:
            msg = q.get(timeout=timeout or self.timeout)
        except queue.Empty:
            self._pending.pop(rid, None)
            raise TimeoutError(f"LSP: нет ответа на {method}")
        if "error" in msg:
            raise RuntimeError(msg["error"].get("message", "ошибка LSP"))
        return msg.get("result")

    def notify(self, method: str, params) -> None:
        self._send({"jsonrpc": "2.0", "method": method, "params": params})

    def _send(self, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        data = f"Content-Length: {len(body)}\r\n\r\n".encode("ascii") + body
        with self._write_lock:
            self.proc.stdin.write(data)
            self.proc.stdin.flush()

    def _reader(self) -> None:
        out = self.proc.stdout
        try:
            while True:
                length = None
                while True:  # заголовки до пустой строки
                    line = out.readline()
                    if not line:
                        return
                    line = line.strip()
                    if not line:
                        break
                    if line.lower().startswith(b"content-length:"):
                        length = int(line.split(b":", 1)[1])
                if length is None:
                    continue
                self._dispatch(json.loads(out.read(length).decode("utf-8")))
        finally:  # сервер завершился: разбудить всех ожидающих
            for q in list(self._pending.values()):
                q.put({"error": {"message": "BSL Language Server остановился"}})

    def _dispatch(self, msg: dict) -> None:
        if "method" in msg and "id" in msg:  # запрос от сервера к клиенту
            result = None
            if msg["method"] == "workspace/configuration":
                result = [None] * len((msg.get("params") or {}).get("items", []))
            self._send({"jsonrpc": "2.0", "id": msg["id"], "result": result})
        elif "id" in msg:  # ответ на наш запрос
            q = self._pending.pop(msg["id"], None)
            if q:
                q.put(msg)


def flatten_symbols(symbols):
    """Обходит дерево символов (регионы содержат вложенные методы)."""
    seen = set()
    for s in symbols:
        rng = s.get("range") or (s.get("location") or {}).get("range")
        if s.get("kind") in (SYMBOL_METHOD, SYMBOL_FUNCTION) and rng and s.get("name") not in seen:
            seen.add(s["name"])
            yield s["name"], rng["start"]["line"], rng["end"]["line"]
        yield from flatten_symbols(s.get("children") or [])
