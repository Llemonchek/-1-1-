"""Граф вызовов: узлы это процедуры («модуль::процедура»), рёбра это вызовы.

Связи ищутся по тексту процедур (комментарии и строки отбрасываются):
  Модуль.Процедура(...)                  вызов общего модуля
  Справочники.Имя.Метод(...)             вызов модуля менеджера
  ЭтотОбъект.Метод(...) и Метод(...)     вызов внутри своего модуля
"""
from __future__ import annotations

import json
import re
import time
from collections import defaultdict
from pathlib import Path

from .parser import WORD

CALL_MGR = re.compile(rf"(?<![\w.])({WORD})\.({WORD})\.({WORD})\s*\(")
CALL_DOT = re.compile(rf"(?<![\w.])({WORD})\.({WORD})\s*\(")
CALL_BARE = re.compile(rf"(?<![\w.])({WORD})\s*\(")
SELF_NAMES = {"этотобъект", "этаформа", "thisobject", "thisform"}

_MANAGERS = {
    "Catalogs": ("справочники", "catalogs"), "Documents": ("документы", "documents"),
    "DataProcessors": ("обработки", "dataprocessors"), "Reports": ("отчеты", "отчёты", "reports"),
    "InformationRegisters": ("регистрысведений", "informationregisters"),
    "AccumulationRegisters": ("регистрынакопления", "accumulationregisters"),
    "AccountingRegisters": ("регистрыбухгалтерии", "accountingregisters"),
    "ChartsOfAccounts": ("планысчетов", "chartsofaccounts"),
    "ChartsOfCharacteristicTypes": ("планывидовхарактеристик", "chartsofcharacteristictypes"),
    "ExchangePlans": ("планыобмена", "exchangeplans"), "Enums": ("перечисления", "enums"),
    "BusinessProcesses": ("бизнеспроцессы", "businessprocesses"), "Tasks": ("задачи", "tasks"),
}
MANAGER_FOLDERS = {alias: folder for folder, aliases in _MANAGERS.items() for alias in aliases}


def strip_noise(code: str) -> str:
    """Убирает строки и комментарии, чтобы не искать вызовы внутри них."""
    code = re.sub(r'"(?:[^"\n]|"")*"', '""', code)           # строки в одной строке
    code = re.sub(r'"[^"\n]*$', '""', code, flags=re.M)       # начало многострочной строки
    code = re.sub(r"^\s*\|.*$", "", code, flags=re.M)          # продолжение многострочной строки
    return re.sub(r"//.*", "", code)


class Graph:
    def __init__(self, modules: dict, edges, module_edges, meta: dict | None = None):
        self.modules = modules
        self.edges = [tuple(e) for e in edges]
        self.module_edges = [tuple(e) for e in module_edges]
        self.meta = meta or {}
        self.procs: dict[str, dict] = {}
        for mid, m in modules.items():
            for p in m["procs"]:
                p["id"] = f"{mid}::{p['name']}"
                p["module"] = mid
                self.procs[p["id"]] = p
        self.out, self.inn = defaultdict(list), defaultdict(list)
        for a, b in self.edges:
            self.out[a].append(b)
            self.inn[b].append(a)
        self.mod_out, self.mod_in = defaultdict(set), defaultdict(set)
        for a, b in self.module_edges:
            self.mod_out[a].add(b)
            self.mod_in[b].add(a)

    # ---- построение -----------------------------------------------------
    @classmethod
    def build(cls, modules: dict, meta: dict | None = None) -> "Graph":
        common = {m["name"].lower(): mid for mid, m in modules.items() if m["folder"] == "CommonModules"}
        managers = {(m["folder"], m["object"].lower()): mid
                    for mid, m in modules.items() if m["mtype"] == "ManagerModule"}
        names = {mid: {p["name"].lower(): p["name"] for p in m["procs"]} for mid, m in modules.items()}
        edges, medges = set(), set()

        def link(src, mid, target, proc):
            if target not in modules:
                return
            if target != mid:
                medges.add((mid, target))
            real = names[target].get(proc.lower())
            if real and f"{target}::{real}" != src:
                edges.add((src, f"{target}::{real}"))

        for mid, m in modules.items():
            for p in m["procs"]:
                src, code = f"{mid}::{p['name']}", strip_noise(p["code"])
                for a, b, c in CALL_MGR.findall(code):
                    folder = MANAGER_FOLDERS.get(a.lower())
                    if folder:
                        link(src, mid, managers.get((folder, b.lower())), c)
                for a, b in CALL_DOT.findall(code):
                    if a.lower() in SELF_NAMES:
                        link(src, mid, mid, b)
                    elif a.lower() in common:
                        link(src, mid, common[a.lower()], b)
                for n in CALL_BARE.findall(code):
                    if n.lower() in names[mid]:
                        link(src, mid, mid, n)

        meta = dict(meta or {}, built_at=time.time())
        return cls(modules, sorted(edges), sorted(medges), meta)

    # ---- запросы --------------------------------------------------------
    def callees(self, nid: str) -> list[str]:
        return self.out.get(nid, [])

    def callers(self, nid: str) -> list[str]:
        return self.inn.get(nid, [])

    def module_uses(self, mid: str) -> list[str]:
        return sorted(self.mod_out.get(mid, ()))

    def module_used_by(self, mid: str) -> list[str]:
        return sorted(self.mod_in.get(mid, ()))

    def stats(self) -> dict:
        return {"modules": len(self.modules), "procs": len(self.procs), "edges": len(self.edges),
                "built_at": self.meta.get("built_at"), "engine": self.meta.get("engine", ""),
                "note": self.meta.get("note", "")}

    # ---- хранение -------------------------------------------------------
    def save(self, path: Path) -> None:
        data = {"meta": self.meta, "modules": self.modules,
                "edges": self.edges, "module_edges": self.module_edges}
        Path(path).write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "Graph":
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(d["modules"], d["edges"], d["module_edges"], d.get("meta"))
