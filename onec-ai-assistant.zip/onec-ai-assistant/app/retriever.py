"""Выбор модуля по вопросу и сборка компактного контекста из графа для маленькой модели."""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

from . import config
from .graph import Graph

_WORDS = re.compile(r"[\wА-Яа-яЁё]+")
_CAMEL = re.compile(r"[А-ЯЁA-Z][а-яёa-z0-9]*")


def _compact(s: str) -> str:
    return re.sub(r"[\W_]+", "", s.lower())


def find_modules(graph: Graph, question: str, limit: int = 3) -> list[tuple[str, int, list[str]]]:
    """Возвращает [(id модуля, оценка, [процедуры из вопроса])] по убыванию оценки."""
    q_low = question.lower()
    q_compact = _compact(question)
    q_stems = {w[:4] for w in _WORDS.findall(q_low) if len(w) >= 4}
    found = []
    for mid, m in graph.modules.items():
        score, focus = 0, []
        name = m["name"].lower()
        if mid.lower() in q_low:
            score += 100
        elif len(name) >= 3 and _compact(name) in q_compact:
            score += 50 + len(name)
        words = [w.lower() for w in _CAMEL.findall(m["name"])]
        score += 8 * sum(1 for w in words if len(w) >= 4 and w[:4] in q_stems)
        for p in m["procs"]:
            if len(p["name"]) >= 4 and p["name"].lower() in q_low:
                focus.append(p["name"])
                score += 30
        if score >= 8:
            found.append((mid, score, focus))
    found.sort(key=lambda x: -x[1])
    return found[:limit]


def _sig(p: dict) -> str:
    return f"{p['label']} {p['name']}({p['params']})" + (" Экспорт" if p["export"] else "")


def _short(nid: str, own: str) -> str:
    mod, _, name = nid.partition("::")
    return name if mod == own else f"{mod}.{name}"


def _describe(graph: Graph, summaries, p: dict, qualify: bool = False) -> str:
    text = summaries.get(p["id"], p["hash"]) or " ".join(p["doc"])[:200]
    text = " ".join(text.split())
    sig = _sig(p)
    if qualify:  # «Функция Имя(...)» -> «Функция Модуль.Имя(...)»
        sig = sig.replace(f" {p['name']}(", f" {p['module']}.{p['name']}(", 1)
    return f"- {sig}" + (f": {text}" if text else "")


def build_context(graph: Graph, mid: str, summaries, focus=(), budget: int | None = None) -> str:
    budget = budget or config.CONTEXT_CHARS
    m = graph.modules[mid]
    procs = m["procs"]
    out = [
        f"МОДУЛЬ: {mid}",
        f"Файл: {m['path']}",
        f"Процедур и функций: {len(procs)}",
        "Использует модули: " + (", ".join(graph.module_uses(mid)[:15]) or "нет"),
        "Используется в модулях: " + (", ".join(graph.module_used_by(mid)[:15]) or "нет"),
        "",
        "ПРОЦЕДУРЫ И ФУНКЦИИ:",
    ]
    for p in procs[:40]:
        line = _describe(graph, summaries, p)
        calls = [_short(c, mid) for c in graph.callees(p["id"])[:6]]
        out.append(line + (f" [вызывает: {', '.join(calls)}]" if calls else ""))
    if len(procs) > 40:
        out.append(f"... и ещё {len(procs) - 40}")

    used = sum(len(x) + 1 for x in out)
    priority = {n: 0 for n in focus}
    ordered = sorted(procs, key=lambda p: (priority.get(p["name"], 1), not p["export"]))
    out += ["", "КОД:"]
    code_limit = used + int((budget - used) * 0.7)
    for p in ordered:
        code = p["code"] if len(p["code"]) <= 1800 else p["code"][:1800] + "\n// ... обрезано"
        if used + len(code) > code_limit:
            continue
        out.append(code + "\n")
        used += len(code) + 1

    outer_calls, outer_callers = [], []
    for p in procs:
        outer_calls += [c for c in graph.callees(p["id"]) if not c.startswith(mid + "::")]
        outer_callers += [(c, p["name"]) for c in graph.callers(p["id"]) if not c.startswith(mid + "::")]
    if outer_calls:
        out.append("ВЫЗЫВАЕТ ИЗ ДРУГИХ МОДУЛЕЙ:")
        for nid in list(dict.fromkeys(outer_calls))[:12]:
            out.append(_describe(graph, summaries, graph.procs[nid], qualify=True))
    if outer_callers:
        out.append("ЭТОТ МОДУЛЬ ВЫЗЫВАЮТ:")
        for nid, target in outer_callers[:10]:
            out.append(f"- {_short(nid, mid)} вызывает {target}")
    return "\n".join(out)


# ====================================================================
# Свободные вопросы: поиск по всей конфигурации (BM25, без внешних библиотек)
# ====================================================================
STOP = set("""как что где какой какая какие какое каким чем для это эти этот при или если ли его её они там про
над под все всех мне нам есть быть был была были может можно нужно надо делает делают работает работают
происходит используется используют расскажи объясни покажи опиши найди модуль модули модуля модулей модуле
процедура процедуры процедуру функция функции функцию код кода конфигурации конфигурация конфигурации
программе приложении почему зачем когда какого какую какому чего кто кому the and for how what where""".split())

_PARTS = re.compile(r"[А-ЯЁA-Z]{2,}(?![а-яёa-z])|[А-ЯЁA-Z]?[а-яёa-z0-9]+")


def terms(text: str, query: bool = False) -> list[str]:
    """Слова и части составных идентификаторов (РасширениеДопустимо -> расш, допу), обрезанные до основы."""
    out = []
    for w in _WORDS.findall(text):
        if query and w.lower() in STOP:
            continue
        for part in (x.lower() for x in _PARTS.findall(w)) or [w.lower()]:
            if len(part) >= 3 and not (query and part in STOP):
                out.append(part[:4] if len(part) >= 5 else part)
    return out


class SearchIndex:
    """Индекс BM25 по процедурам: имя, модуль, комментарий, описание модели и код."""
    K1, B = 1.4, 0.75

    def __init__(self, graph: Graph, summaries):
        self.built_at = graph.meta.get("built_at")
        self.n_sum = len(summaries.data)
        self.post: dict[str, list] = defaultdict(list)
        self.ids: list[str] = []
        self.len: list[int] = []
        for nid, p in graph.procs.items():
            c: Counter = Counter()
            fields = ((p["name"], 4), (graph.modules[p["module"]]["name"], 2), (" ".join(p["doc"]), 2),
                      (summaries.get(nid, p["hash"]) or "", 2), (p["code"], 1))
            for text, weight in fields:
                for t in terms(text):
                    c[t] += weight
            i = len(self.ids)
            self.ids.append(nid)
            self.len.append(sum(c.values()) or 1)
            for t, f in c.items():
                self.post[t].append((i, f))
        self.avg = sum(self.len) / max(1, len(self.len))

    def search(self, question: str, limit: int = 8) -> list[tuple[str, float]]:
        q = set(terms(question, query=True))
        n, scores = len(self.ids), defaultdict(float)
        for t in q:
            posts = self.post.get(t)
            if not posts:
                continue
            idf = math.log(1 + (n - len(posts) + 0.5) / (len(posts) + 0.5))
            for i, f in posts:
                scores[i] += idf * f * (self.K1 + 1) / (f + self.K1 * (1 - self.B + self.B * self.len[i] / self.avg))
        top = sorted(scores.items(), key=lambda x: -x[1])[:limit]
        return [(self.ids[i], sc) for i, sc in top]


def route(graph: Graph, question: str, index: SearchIndex, module: str | None = None) -> dict:
    """Выбирает режим: module (модуль назван), search (поиск по процедурам), overview (общий вопрос)."""
    if module and module in graph.modules:
        return {"mode": "module", "modules": [module], "module": module, "focus": []}
    by_name = find_modules(graph, question)
    strong = [h for h in by_name if h[1] >= 50]
    if strong:  # модуль назван явно (возможно, два сразу)
        mods = [h[0] for h in strong[:2]]
        return {"mode": "module", "modules": mods, "module": mods[0], "focus": strong[0][2]}
    if by_name and by_name[0][2] and (len(by_name) == 1 or by_name[0][1] > by_name[1][1]):
        return {"mode": "module", "modules": [by_name[0][0]], "module": by_name[0][0], "focus": by_name[0][2]}
    hits = index.search(question)
    if hits:
        hits = [h for h in hits if h[1] >= hits[0][1] * 0.3]
        return {"mode": "search", "hits": hits, "module": graph.procs[hits[0][0]]["module"]}
    return {"mode": "overview", "module": None}


def build_search_context(graph: Graph, hits, summaries, budget: int | None = None) -> str:
    budget = budget or config.CONTEXT_CHARS
    out = ["НАЙДЕННЫЕ ПО ВОПРОСУ ПРОЦЕДУРЫ И ФУНКЦИИ (по убыванию релевантности):"]
    used, mods = len(out[0]), []
    for rank, (nid, _score) in enumerate(hits, 1):
        p = graph.procs[nid]
        mid = p["module"]
        if mid not in mods:
            mods.append(mid)
        head = [f"\n[{rank}] {mid} :: {_sig(p)}", f"Файл: {graph.modules[mid]['path']}, строка {p['line']}"]
        text = " ".join((summaries.get(nid, p["hash"]) or " ".join(p["doc"])).split())
        if text:
            head.append("Описание: " + text[:300])
        calls = [_short(c, mid) for c in graph.callees(nid)[:8]]
        callers = [_short(c, mid) for c in graph.callers(nid)[:8]]
        head += ["Вызывает: " + (", ".join(calls) or "нет"), "Вызывается из: " + (", ".join(callers) or "нет")]
        head_text = "\n".join(head)
        code = p["code"] if len(p["code"]) <= 1500 else p["code"][:1500] + "\n// ... обрезано"
        block = head_text + "\nКод:\n" + code if used + len(head_text) + len(code) <= budget else head_text
        out.append(block)
        used += len(block)
    out.append("\nМОДУЛИ, В КОТОРЫХ НАЙДЕНО:")
    for mid in mods[:5]:
        out.append(f"- {mid}: использует {', '.join(graph.module_uses(mid)[:6]) or 'нет'}; "
                   f"используется в {', '.join(graph.module_used_by(mid)[:6]) or 'нет'}")
    return "\n".join(out)


def build_overview(graph: Graph) -> str:
    st = graph.stats()
    top = sorted(graph.modules, key=lambda m: -len(graph.mod_in.get(m, ())))[:10]
    out = [f"ОБЗОР КОНФИГУРАЦИИ: модулей {st['modules']}, процедур и функций {st['procs']}, связей вызовов {st['edges']}.",
           "Конкретных процедур по вопросу не найдено. Чаще всего используются модули: " + ", ".join(top),
           "", "МОДУЛИ:"]
    for mid in list(graph.modules)[:60]:
        out.append(f"- {mid} ({len(graph.modules[mid]['procs'])} проц.)")
    if len(graph.modules) > 60:
        out.append(f"... и ещё {len(graph.modules) - 60}")
    return "\n".join(out)
