"""Сканирование выгрузки 1С и разбор .bsl модулей на процедуры и функции.

Границы процедур берутся из BSL Language Server (documentSymbol). Если он не
настроен или недоступен, используется встроенный разбор по регулярным выражениям.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

from . import config
from .bsl_ls import BslLanguageServer, flatten_symbols  # noqa: F401

WORD = r"[\wА-Яа-яЁё]+"
DEF_RE = re.compile(
    rf"^[ \t]*(Процедура|Функция|Procedure|Function)[ \t]+({WORD})[ \t]*\(([^)]*)\)[ \t]*(Экспорт|Export)?",
    re.I | re.M,
)
END_RE = re.compile(r"^[ \t]*(КонецПроцедуры|КонецФункции|EndProcedure|EndFunction)\b", re.I | re.M)

# Папки верхнего уровня выгрузки (формат Конфигуратора и EDT)
FOLDERS = {
    "CommonModules", "Catalogs", "Documents", "DataProcessors", "Reports", "InformationRegisters",
    "AccumulationRegisters", "AccountingRegisters", "CalculationRegisters", "ChartsOfAccounts",
    "ChartsOfCharacteristicTypes", "ChartsOfCalculationTypes", "BusinessProcesses", "Tasks",
    "ExchangePlans", "Enums", "Constants", "CommonForms", "CommonCommands", "DocumentJournals",
    "SettingsStorages", "WebServices", "HTTPServices", "FilterCriteria", "SessionParameters",
}


def scan(root: Path) -> list[Path]:
    files = []
    for p in Path(root).rglob("*.bsl"):
        if any(part in config.SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        files.append(p)
    return sorted(files)


def read_text(path: Path) -> str:
    raw = path.read_bytes()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1251", errors="replace")


def module_identity(rel: Path) -> dict:
    """Определяет тип и имя модуля по пути файла в выгрузке."""
    parts = list(rel.parts)
    stem = rel.stem
    idx = next((i for i, p in enumerate(parts) if p in FOLDERS and i + 2 < len(parts)), None)
    if idx is None:  # например, Ext/ManagedApplicationModule.bsl
        return {"id": rel.with_suffix("").as_posix().replace("/", "."), "folder": "",
                "object": stem, "mtype": stem, "name": stem}
    folder, obj, rest = parts[idx], parts[idx + 1], parts[idx + 2:]
    if "Forms" in rest and rest.index("Forms") + 1 < len(rest):
        mtype = "Form." + rest[rest.index("Forms") + 1]
    elif folder == "CommonForms":
        mtype = "Form"
    elif folder == "CommonModules":
        mtype = "Module"
    else:
        mtype = stem
    mid = obj if folder == "CommonModules" else f"{folder}.{obj}.{mtype}"
    return {"id": mid, "folder": folder, "object": obj, "mtype": mtype, "name": obj}


def _build_proc(lines: list[str], start: int, end: int) -> dict | None:
    """Собирает описание процедуры по диапазону строк (включая директиву и комментарий над ней)."""
    code = "\n".join(lines[start:end + 1])
    m = DEF_RE.search(code)
    if not m:
        return None
    s, doc = start, []
    while s > 0 and lines[s - 1].strip().startswith(("//", "&")):
        s -= 1
        t = lines[s].strip()
        if t.startswith("//"):
            doc.insert(0, t.lstrip("/ ").strip())
    full = "\n".join(lines[s:end + 1])
    return {
        "name": m.group(2),
        "label": "Функция" if m.group(1).lower() in ("функция", "function") else "Процедура",
        "params": " ".join(m.group(3).split()),
        "export": bool(m.group(4)),
        "line": start + 1,
        "doc": [d for d in doc if d],
        "code": full,
        "hash": hashlib.sha1(full.encode("utf-8")).hexdigest()[:12],
    }


def parse_regex(text: str) -> list[dict]:
    lines, procs = text.splitlines(), []
    for m in DEF_RE.finditer(text):
        e = END_RE.search(text, m.end())
        if not e:
            continue
        p = _build_proc(lines, text.count("\n", 0, m.start()), text.count("\n", 0, e.start()))
        if p:
            procs.append(p)
    return procs


def procs_from_symbols(text: str, symbols: list[tuple[str, int, int]]) -> list[dict]:
    lines, procs = text.splitlines(), []
    for _name, start, end in symbols:
        p = _build_proc(lines, start, min(end, len(lines) - 1))
        if p:
            procs.append(p)
    return procs


def config_fingerprint(root: Path) -> str:
    """Отпечаток выгрузки: имена, время изменения и размеры всех .bsl. Меняется при любой правке."""
    h = hashlib.sha1()
    for f in scan(Path(root)):
        try:
            st = f.stat()
        except OSError:
            continue
        h.update(f"{f.relative_to(root).as_posix()}|{st.st_mtime_ns}|{st.st_size}\n".encode("utf-8"))
    return h.hexdigest()


def parse_config(root: Path, progress=None, previous: dict | None = None) -> tuple[dict, dict]:
    """Разбирает модули. Возвращает (modules, meta). progress(i, total, файл).

    previous: модули прошлого разбора; файлы, которые не менялись, берутся оттуда без повторного разбора.
    """
    root = Path(root)
    files = scan(root)
    if not files:
        raise RuntimeError(f"В папке нет файлов .bsl: {root}")
    cache = {m["path"]: m for m in (previous or {}).values()}
    cmd = config.bsl_ls_command()
    st_ls = {"lsp": None, "tried": False, "note": ""}

    def lsp():  # сервер запускается только если есть что разбирать
        if st_ls["lsp"] or st_ls["tried"] or not cmd:
            return st_ls["lsp"]
        st_ls["tried"] = True
        server = BslLanguageServer(cmd, root, config.BSL_LS_TIMEOUT)
        try:
            server.start()
            st_ls["lsp"] = server
        except Exception as e:  # не нашли java/jar, не стартовал сервер
            st_ls["note"] = f"BSL Language Server недоступен ({e}), используется встроенный разбор"
            server.close()
        return st_ls["lsp"]

    counts = {"lsp": 0, "regex": 0, "reused": 0}
    modules: dict[str, dict] = {}
    try:
        for i, f in enumerate(files, 1):
            rel = f.relative_to(root)
            rel_s = rel.as_posix()
            try:
                st = f.stat()
            except OSError:  # файл исчез во время разбора
                continue
            old = cache.get(rel_s)
            if old and old.get("mtime_ns") == st.st_mtime_ns and old.get("size") == st.st_size:
                procs, lines = [dict(p) for p in old["procs"]], old["lines"]
                counts["reused"] += 1
            else:
                text = read_text(f)
                lines, procs = text.count("\n") + 1, None
                server = lsp()
                if server:
                    try:
                        procs = procs_from_symbols(text, server.document_symbols(f, text))
                        if not procs and DEF_RE.search(text):
                            procs = None  # сервер вернул пусто, а процедуры в файле есть
                    except Exception as e:
                        st_ls["note"] = f"BSL Language Server отказал на {f.name} ({e}), дальше встроенный разбор"
                        server.close()
                        st_ls["lsp"] = None
                if procs is None:
                    procs = parse_regex(text)
                    counts["regex"] += 1
                else:
                    counts["lsp"] += 1
            ident = module_identity(rel)
            mid, n = ident["id"], 2
            while mid in modules:
                mid, n = f"{ident['id']}#{n}", n + 1
            modules[mid] = {**ident, "id": mid, "path": rel_s, "procs": procs, "lines": lines,
                            "mtime_ns": st.st_mtime_ns, "size": st.st_size}
            if progress:
                progress(i, len(files), rel_s)
    finally:
        if st_ls["lsp"]:
            st_ls["lsp"].close()

    if counts["lsp"] and not counts["regex"]:
        engine = "BSL Language Server"
    elif counts["regex"] and not counts["lsp"]:
        engine = "встроенный разбор"
    elif counts["lsp"]:
        engine = "BSL Language Server + встроенный разбор"
    else:
        engine = ""  # ничего не менялось, движок возьмётся из прошлого разбора
    return modules, {"engine": engine, "note": st_ls["note"],
                     "parsed": counts["lsp"] + counts["regex"], "reused": counts["reused"]}
