"""Локальное хранилище: кэш описаний процедур, обратная связь, фоновые задачи."""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path


class Summaries:
    """Кэш кратких описаний процедур. Ключ: id процедуры + хэш её кода."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.lock = threading.Lock()
        try:
            self.data: dict = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = {}

    def get(self, nid: str, code_hash: str) -> str | None:
        e = self.data.get(nid)
        return e["text"] if e and e.get("h") == code_hash else None

    def set(self, nid: str, code_hash: str, text: str) -> None:
        with self.lock:
            self.data[nid] = {"h": code_hash, "text": text}

    def save(self) -> None:
        with self.lock:
            self.path.write_text(json.dumps(self.data, ensure_ascii=False), encoding="utf-8")


class Feedback:
    """Оценки и правки ответов. Хорошие ответы идут в промпт как примеры (few-shot)."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.lock = threading.Lock()

    def add(self, module: str | None, question: str, answer: str, rating: int,
            correction: str | None = None, by: str | None = None) -> None:
        entry = {"ts": int(time.time()), "module": module, "question": question,
                 "answer": answer, "rating": rating, "correction": correction or None, "by": by}
        with self.lock, self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def _all(self) -> list[dict]:
        try:
            lines = self.path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        out = []
        for ln in lines:
            try:
                out.append(json.loads(ln))
            except ValueError:
                pass
        return out

    def examples(self, module: str | None, limit: int = 2) -> list[tuple[str, str]]:
        """Пары (вопрос, образцовый ответ) по этому модулю: правка разработчика важнее оценки."""
        good = []
        for e in self._all():
            if e.get("module") != module:
                continue
            answer = e.get("correction") or (e["answer"] if e.get("rating", 0) > 0 else None)
            if answer:
                good.append((e["question"][:300], answer[:1500]))
        return good[-limit:]

    def count(self) -> int:
        return len(self._all())


class Job:
    """Одна фоновая задача с прогрессом (разбор конфигурации, генерация описаний)."""

    def __init__(self):
        self.state = self._fresh()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    @staticmethod
    def _fresh(running: bool = False) -> dict:
        return {"running": running, "done": 0, "total": 0, "current": "", "error": None, "message": ""}

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    @property
    def stopped(self) -> bool:
        return self._stop.is_set()

    def start(self, fn) -> bool:
        if self.running:
            return False
        self.state = self._fresh(True)
        self._stop.clear()

        def runner():
            try:
                fn(self)
            except Exception as e:
                self.state["error"] = str(e)
            finally:
                self.state["running"] = False

        self._thread = threading.Thread(target=runner, daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()

    def update(self, **kw) -> None:
        self.state.update(kw)
