"""Веб-приложение: вопросы к модели, роли, автоматическое обновление данных из папки с выгрузкой."""
from __future__ import annotations

import json
import threading
import time
import urllib.parse
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import PlainTextResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import auth, config, llm
from .docs import module_doc, summarize_all
from .graph import Graph
from .parser import config_fingerprint, parse_config
from .retriever import (SearchIndex, build_context, build_overview, build_search_context,
                        route)
from .store import Feedback, Job, Summaries

app = FastAPI(title="Помощник по коду 1С")

summaries = Summaries(config.SUMMARIES_FILE)
feedback = Feedback(config.FEEDBACK_FILE)
parse_job, summary_job = Job(), Job()
graph: Graph | None = Graph.load(config.GRAPH_FILE) if config.GRAPH_FILE.exists() else None
_health = {"t": 0.0, "v": {}}

# Что уже разобрано: если отпечаток папки не изменился, повторный разбор не нужен
scan = {"last_check": None, "attempted": None, "error": None}
if graph and graph.meta.get("root") == str(config.CONFIG_DIR):
    scan["attempted"] = graph.meta.get("fingerprint")


# ================================================================ доступ и роли
def current_user(request: Request) -> dict | None:
    return auth.read_token(request.cookies.get("session"))


def me_payload(user: dict | None) -> dict:
    role = user["role"] if user else "guest"
    return {"name": user["name"] if user else None, "role": role, "role_title": auth.ROLE_TITLES[role],
            "can_rate": role == "lead", "login_required": config.REQUIRE_LOGIN}


def require_member(request: Request) -> None:
    """Задавать вопросы: все, а при REQUIRE_LOGIN=1 только вошедшие."""
    if config.REQUIRE_LOGIN and not current_user(request):
        raise HTTPException(401, "Войдите в систему")


def require_lead(request: Request) -> dict:
    user = current_user(request)
    if not user:
        raise HTTPException(401, "Войдите как главный программист")
    if user["role"] != "lead":
        raise HTTPException(403, "Это действие доступно только главному программисту")
    return user


class LoginBody(BaseModel):
    name: str
    password: str


@app.post("/api/login")
def login(body: LoginBody, response: Response):
    try:
        user = auth.login(body.name, body.password)
    except PermissionError as e:
        raise HTTPException(429, str(e))
    if not user:
        raise HTTPException(401, "Неверное имя или пароль")
    response.set_cookie("session", auth.make_token(user), httponly=True, samesite="lax",
                        max_age=config.SESSION_HOURS * 3600)
    return me_payload(user)


@app.post("/api/logout")
def logout(response: Response):
    response.delete_cookie("session")
    return {"ok": True}


@app.get("/api/me")
def me(request: Request):
    return me_payload(current_user(request))


# ================================================================ автоматическое обновление данных
_index: SearchIndex | None = None
_index_lock = threading.Lock()


def get_index(g: Graph) -> SearchIndex:
    """Индекс поиска пересобирается при новом разборе и когда заметно выросло число описаний."""
    global _index
    with _index_lock:
        i = _index
        grown = len(summaries.data) - (i.n_sum if i else 0)
        stale = (i is None or i.built_at != g.meta.get("built_at")
                 or (grown != 0 and (not summary_job.running or abs(grown) >= 25)))
        if stale:
            _index = SearchIndex(g, summaries)
        return _index


def _reparse(job: Job, root: Path, fp: str) -> None:
    global graph
    old = graph
    job.update(message="Обновляю данные")
    modules, meta = parse_config(root, lambda i, n, f: job.update(done=i, total=n, current=f),
                                 previous=old.modules if old else None)
    if not meta["parsed"] and old:  # ничего не пересобирали: движок и заметка как в прошлый раз
        meta["engine"], meta["note"] = old.meta.get("engine", ""), old.meta.get("note", "")
    meta.update(fingerprint=fp, root=str(root))
    job.update(message="Строю граф зависимостей", current="")
    g = Graph.build(modules, meta)
    g.save(config.GRAPH_FILE)
    graph = g
    job.update(message="Строю поисковый индекс")
    get_index(g)
    job.update(message="Данные актуальны")


def check_config() -> None:
    """Сравнивает отпечаток папки с тем, что уже разобрано; при отличии запускает обновление."""
    root = config.CONFIG_DIR
    scan["last_check"] = time.time()
    if not root.is_dir():
        return
    fp = config_fingerprint(root)
    if fp == scan["attempted"] or parse_job.running:
        return
    scan["attempted"] = fp  # при ошибке не повторяем, пока файлы не изменятся
    parse_job.start(lambda job: _reparse(job, root, fp))


def _watch() -> None:
    while True:
        try:
            check_config()
            scan["error"] = None
        except Exception as e:
            scan["error"] = str(e)
        time.sleep(config.SCAN_INTERVAL)


def need_graph() -> Graph:
    if graph is None:
        raise HTTPException(409, "Данные ещё не загружены: идёт первый разбор конфигурации, подождите немного")
    return graph


# ================================================================ статус
@app.get("/api/status")
def status(request: Request):
    if time.time() - _health["t"] > 5:
        _health.update(t=time.time(), v=llm.health())
    g, lead = graph, (current_user(request) or {}).get("role") == "lead"
    done = sum(1 for nid, p in g.procs.items() if summaries.get(nid, p["hash"])) if g else 0
    return {
        "ollama": _health["v"],
        "config_dir": str(config.CONFIG_DIR) if lead else None,  # путь на сервере видит только главный
        "bsl_ls": bool(config.bsl_ls_command()),
        "graph": g.stats() if g else None,
        "parse": parse_job.state,
        "scan": {"interval": config.SCAN_INTERVAL, "auto": config.AUTO_SCAN, "last_check": scan["last_check"],
                 "folder_ok": config.CONFIG_DIR.is_dir(), "error": scan["error"]},
        "summarize": summary_job.state,
        "summaries": {"done": done, "total": len(g.procs) if g else 0},
        "feedback": feedback.count() if lead else None,
    }


@app.get("/api/modules")
def modules(request: Request):
    require_member(request)
    g = need_graph()
    return [{"id": mid, "procs": len(m["procs"]), "path": m["path"]} for mid, m in sorted(g.modules.items())]


@app.get("/api/map")
def module_map(module: str, request: Request):
    require_member(request)
    g = need_graph()
    if module not in g.modules:
        raise HTTPException(404, "Модуль не найден")
    return {"center": module, "procs": len(g.modules[module]["procs"]),
            "uses": g.module_uses(module), "used_by": g.module_used_by(module)}


# ================================================================ вопросы (все роли)
class AskBody(BaseModel):
    question: str
    module: str | None = None


def _line(obj: dict) -> str:
    return json.dumps(obj, ensure_ascii=False) + "\n"


@app.post("/api/ask")
def ask(body: AskBody, request: Request):
    require_member(request)
    g = need_graph()
    question = body.question.strip()
    if not question:
        raise HTTPException(400, "Пустой вопрос")

    def stream():
        r = route(g, question, get_index(g), body.module)
        examples: list = []
        if r["mode"] == "module":
            n = len(r["modules"])
            context = "\n\n".join(
                build_context(g, m, summaries, r["focus"] if i == 0 else (), config.CONTEXT_CHARS // n)
                for i, m in enumerate(r["modules"]))
            examples = feedback.examples(r["module"])
        elif r["mode"] == "search":
            context = build_search_context(g, r["hits"], summaries)
        else:
            context = build_overview(g)
        meta = {"mode": r["mode"], "module": r["module"], "modules": r.get("modules", []),
                "hits": [{"module": g.procs[n]["module"], "proc": g.procs[n]["name"]} for n, _ in r.get("hits", [])],
                "context_chars": len(context), "examples": len(examples)}
        yield _line({"meta": meta})
        try:
            for piece in llm.chat_stream(llm.qa_messages(question, context, examples, r["mode"])):
                yield _line({"t": piece})
        except Exception as e:
            yield _line({"error": f"Модель недоступна: {e}"})

    return StreamingResponse(stream(), media_type="application/x-ndjson")


# ================================================================ только главный программист
@app.post("/api/summarize")
def summarize(request: Request):
    require_lead(request)
    g = need_graph()
    if not summary_job.start(lambda job: summarize_all(job, g, summaries)):
        raise HTTPException(409, "Генерация уже выполняется")
    return {"started": True}


@app.post("/api/summarize/stop")
def summarize_stop(request: Request):
    require_lead(request)
    summary_job.stop()
    return {"stopping": True}


@app.get("/api/doc")
def doc(module: str, request: Request, overview: bool = True):
    require_lead(request)
    g = need_graph()
    if module not in g.modules:
        raise HTTPException(404, "Модуль не найден")
    name = urllib.parse.quote(f"{module}.md")
    return PlainTextResponse(module_doc(g, module, summaries, overview), media_type="text/markdown; charset=utf-8",
                             headers={"Content-Disposition": f"inline; filename*=UTF-8''{name}"})


class FeedbackBody(BaseModel):
    module: str | None = None
    question: str
    answer: str
    rating: int
    correction: str | None = None


@app.post("/api/feedback")
def add_feedback(body: FeedbackBody, request: Request):
    user = require_lead(request)
    feedback.add(body.module, body.question, body.answer, 1 if body.rating > 0 else -1,
                 body.correction, by=user["name"])
    return {"ok": True, "total": feedback.count()}


if config.AUTO_SCAN:
    threading.Thread(target=_watch, daemon=True, name="config-watcher").start()

app.mount("/", StaticFiles(directory=config.ROOT / "frontend", html=True), name="ui")
