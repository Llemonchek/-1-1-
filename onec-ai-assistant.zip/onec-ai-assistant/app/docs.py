"""Автодокументация: описания процедур по единому шаблону и Markdown-документ модуля."""
from __future__ import annotations

from . import llm
from .graph import Graph
from .retriever import _short, _sig
from .store import Job, Summaries


def summarize_all(job: Job, graph: Graph, summaries: Summaries) -> None:
    """Проходит по всем процедурам и кэширует описания (повторный запуск пропускает готовые)."""
    items = list(graph.procs.items())
    job.update(total=len(items), done=0, message="Генерирую описания процедур")
    for i, (nid, p) in enumerate(items, 1):
        if job.stopped:
            job.update(message="Остановлено")
            break
        job.update(done=i - 1, current=nid)
        if summaries.get(nid, p["hash"]):
            continue
        text = llm.chat(llm.summary_messages(p, graph.callees(nid)))
        if text:
            summaries.set(nid, p["hash"], text)
        if i % 5 == 0:
            summaries.save()
    summaries.save()
    job.update(done=job.state["total"] if not job.stopped else job.state["done"], current="")


def module_doc(graph: Graph, mid: str, summaries: Summaries, with_overview: bool = True) -> str:
    m = graph.modules[mid]
    lines = [f"# Модуль {mid}", "", f"Файл: `{m['path']}`", ""]
    index = "\n".join(f"{_sig(p)}: {' '.join((summaries.get(p['id'], p['hash']) or ' '.join(p['doc'])).split())}"
                      for p in m["procs"][:30])
    if with_overview and index:
        try:
            lines += [llm.chat(llm.overview_messages(mid, index)), ""]
        except Exception:
            pass  # модель недоступна: документ строится без вступления
    uses, used_by = graph.module_uses(mid), graph.module_used_by(mid)
    lines += ["## Зависимости", "",
              "- Использует: " + (", ".join(uses) or "нет"),
              "- Используется в: " + (", ".join(used_by) or "нет"), "",
              "## Процедуры и функции", ""]
    for p in m["procs"]:
        lines.append(f"### {_sig(p)}")
        text = summaries.get(p["id"], p["hash"]) or "\n".join(p["doc"])
        if text:
            lines += ["", *[ln + "  " for ln in text.splitlines()]]
        calls = [_short(c, mid) for c in graph.callees(p["id"])]
        callers = [_short(c, mid) for c in graph.callers(p["id"])]
        lines += ["", f"Вызывает: {', '.join(calls) or 'нет'}", f"Вызывается из: {', '.join(callers) or 'нет'}", ""]
    return "\n".join(lines)
