"""Работа с локальной моделью через Ollama и шаблоны промптов."""
from __future__ import annotations

import json

import requests

from . import config

SYSTEM_QA = (
    "Ты аналитик кода 1С:Предприятие (язык BSL). Отвечай по-русски, коротко и по делу, "
    "только на основании переданного контекста: код, описания процедур, связи между модулями. "
    "Если в контексте нет данных для ответа, прямо скажи об этом и не выдумывай. "
    "Называй процедуры и модули точными именами из контекста.\n"
    "Структура ответа:\n"
    "1. Назначение модуля.\n"
    "2. Ключевые процедуры и функции и что каждая делает.\n"
    "3. Зависимости: что модуль вызывает и где он используется."
)

SYSTEM_FREE = (
    "Ты аналитик кода 1С:Предприятие (язык BSL). Отвечай по-русски, прямо на заданный вопрос, "
    "только на основании переданного контекста: найденные процедуры, их код, описания и связи. "
    "Называй процедуры и модули точными именами и указывай, где они находятся. "
    "Если в контексте нет ответа, скажи, чего именно не хватает, и предложи уточнить вопрос. Не выдумывай. "
    "На обзорные вопросы о конфигурации отвечай по разделу ОБЗОР."
)

SYSTEM_SUMMARY = (
    "Ты документируешь код 1С (BSL). Опиши процедуру строго по шаблону, по-русски, без вступлений:\n"
    "Назначение: <одно предложение>\n"
    "Параметры: <кратко, что передаётся, или «нет»>\n"
    "Результат: <что возвращает, или «нет»>"
)


def _options(temperature: float) -> dict:
    return {"temperature": temperature, "num_ctx": config.NUM_CTX}


def chat_stream(messages: list[dict], temperature: float = 0.2):
    """Генератор кусочков текста ответа модели."""
    r = requests.post(
        f"{config.OLLAMA_URL}/api/chat",
        json={"model": config.MODEL, "messages": messages, "stream": True, "options": _options(temperature)},
        stream=True,
        timeout=(5, 600),
    )
    if r.status_code != 200:
        raise RuntimeError(f"Ollama вернул {r.status_code}: {r.text[:200]}")
    for line in r.iter_lines():
        if not line:
            continue
        d = json.loads(line)
        if d.get("error"):
            raise RuntimeError(d["error"])
        piece = (d.get("message") or {}).get("content", "")
        if piece:
            yield piece
        if d.get("done"):
            break


def chat(messages: list[dict], temperature: float = 0.1) -> str:
    return "".join(chat_stream(messages, temperature)).strip()


def health() -> dict:
    """Доступна ли Ollama и скачана ли нужная модель."""
    try:
        r = requests.get(f"{config.OLLAMA_URL}/api/tags", timeout=2)
        r.raise_for_status()
        names = [m.get("name", "") for m in r.json().get("models", [])]
        have = any(n == config.MODEL or n.split(":")[0] == config.MODEL for n in names)
        return {"ok": True, "model": config.MODEL, "model_ready": have}
    except Exception as e:
        return {"ok": False, "model": config.MODEL, "model_ready": False, "error": str(e)[:120]}


def qa_messages(question: str, context: str, examples: list[tuple[str, str]], mode: str = "module") -> list[dict]:
    msgs = [{"role": "system", "content": SYSTEM_QA if mode == "module" else SYSTEM_FREE}]
    for q, a in examples:  # образцы от главного разработчика
        msgs += [{"role": "user", "content": q}, {"role": "assistant", "content": a}]
    msgs.append({"role": "user", "content": f"КОНТЕКСТ\n{context}\n\nВОПРОС\n{question}"})
    return msgs


def summary_messages(proc: dict, callees: list[str]) -> list[dict]:
    code = proc["code"][:3000]
    extra = f"\nВызывает: {', '.join(c.split('::')[-1] for c in callees[:8])}" if callees else ""
    return [
        {"role": "system", "content": SYSTEM_SUMMARY},
        {"role": "user", "content": f"{code}{extra}"},
    ]


def overview_messages(module_id: str, index: str) -> list[dict]:
    return [
        {"role": "system", "content": "Ты документируешь модуль 1С. Напиши абзац из 2-3 предложений "
                                       "по-русски: для чего модуль и что в нём главное. Только по данным ниже."},
        {"role": "user", "content": f"Модуль {module_id}\n{index}"},
    ]
