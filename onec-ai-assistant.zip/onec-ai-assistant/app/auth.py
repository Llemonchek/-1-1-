"""Учётные записи и роли. Только стандартная библиотека.

Роли:
  lead  главный программист: задаёт вопросы, отмечает ответы верными/неверными, запускает описания, документацию
  user  обычный пользователь: только задаёт вопросы
  без входа (гость): то же, что user, если не включён REQUIRE_LOGIN
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time

from . import config

ROLE_TITLES = {"lead": "главный программист", "user": "пользователь", "guest": "гость"}
MIN_PASSWORD = 6
_lock = threading.Lock()
_fails: dict[str, list[float]] = {}
_secret_cache: bytes | None = None


# ---- пароли ------------------------------------------------------------
def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200_000)
    return f"pbkdf2${salt.hex()}${dk.hex()}"


def check_password(password: str, stored: str) -> bool:
    try:
        _, salt, dk = stored.split("$")
        cand = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 200_000)
    except ValueError:
        return False
    return hmac.compare_digest(cand.hex(), dk)


_DUMMY = hash_password("нет-такого-пользователя")  # чтобы вход несуществующего имени занимал столько же времени


# ---- файл пользователей --------------------------------------------------
def load_users() -> dict:
    try:
        return json.loads(config.USERS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_users(users: dict) -> None:
    tmp = config.USERS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(users, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, config.USERS_FILE)
    try:
        os.chmod(config.USERS_FILE, 0o600)
    except OSError:
        pass


def add_user(name: str, role: str, password: str) -> None:
    """Создаёт пользователя или меняет роль и пароль существующего."""
    name = name.strip()
    if not name:
        raise ValueError("Пустое имя")
    if role not in ("lead", "user"):
        raise ValueError("Роль должна быть lead или user")
    if len(password) < MIN_PASSWORD:
        raise ValueError(f"Пароль короче {MIN_PASSWORD} символов")
    with _lock:
        users = load_users()
        users[name] = {"role": role, "hash": hash_password(password)}
        _save_users(users)


def remove_user(name: str) -> bool:
    with _lock:
        users = load_users()
        if name not in users:
            return False
        del users[name]
        _save_users(users)
        return True


# ---- вход и сессии -------------------------------------------------------
def login(name: str, password: str) -> dict | None:
    """Проверяет пароль. None: неверно. PermissionError: слишком много неудачных попыток."""
    name, now = (name or "").strip(), time.time()
    with _lock:
        recent = [t for t in _fails.get(name, []) if now - t < 60]
        _fails[name] = recent
        if len(recent) >= 5:
            raise PermissionError("Слишком много неудачных попыток, подождите перед следующей попыткой")
    user = load_users().get(name)
    ok = check_password(password or "", user["hash"] if user else _DUMMY) and user is not None
    with _lock:
        if not ok:
            _fails[name].append(now)
            return None
        _fails.pop(name, None)
    return {"name": name, "role": user["role"]}


def _secret() -> bytes:
    global _secret_cache
    with _lock:
        if _secret_cache is None:
            try:
                _secret_cache = config.SECRET_FILE.read_bytes()
            except OSError:
                _secret_cache = secrets.token_bytes(32)
                config.SECRET_FILE.write_bytes(_secret_cache)
                try:
                    os.chmod(config.SECRET_FILE, 0o600)
                except OSError:
                    pass
        return _secret_cache


def _sign(payload: str) -> str:
    return hmac.new(_secret(), payload.encode("ascii"), "sha256").hexdigest()


def make_token(user: dict) -> str:
    body = json.dumps({"u": user["name"], "exp": int(time.time()) + config.SESSION_HOURS * 3600},
                      ensure_ascii=False).encode("utf-8")
    payload = base64.urlsafe_b64encode(body).decode("ascii").rstrip("=")
    return f"{payload}.{_sign(payload)}"


def read_token(token: str | None) -> dict | None:
    """Возвращает {name, role} по cookie или None. Роль берётся из файла пользователей, а не из cookie:
    удалённый пользователь теряет доступ, а смена роли действует сразу."""
    if not token or "." not in token:
        return None
    payload, sig = token.rsplit(".", 1)
    try:
        if not hmac.compare_digest(_sign(payload), sig):
            return None
        data = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
    except (ValueError, UnicodeError):
        return None
    if data.get("exp", 0) < time.time():
        return None
    user = load_users().get(data.get("u"))
    return {"name": data["u"], "role": user["role"]} if user else None
