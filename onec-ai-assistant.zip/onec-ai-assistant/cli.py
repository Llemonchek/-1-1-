"""Консольная версия помощника по коду 1С.

  python cli.py                  чат: сначала разбор (если ещё не делали), потом вопросы
  python cli.py parse [папка]    только разобрать выгрузку
  python cli.py describe         сгенерировать описания процедур (необязательно, улучшает ответы)
  python cli.py ask "вопрос"     один вопрос и выход

В чате: /parse [папка], /describe, /exit
"""
from __future__ import annotations

import sys
from pathlib import Path

from app import config, llm
from app.docs import summarize_all
from app.graph import Graph
from app.parser import parse_config
from app.retriever import SearchIndex, build_context, build_overview, build_search_context, route
from app.store import Job, Summaries

summaries = Summaries(config.SUMMARIES_FILE)
graph: Graph | None = Graph.load(config.GRAPH_FILE) if config.GRAPH_FILE.exists() else None
index: SearchIndex | None = None


def do_parse(folder: str | None = None) -> None:
    global graph, index
    root = Path(folder) if folder else config.CONFIG_DIR
    if not root.is_dir():
        print(f"Папка не найдена: {root}")
        return
    try:
        modules, meta = parse_config(root, lambda i, n, f: print(f"\rРазбор: {i}/{n}", end="", flush=True),
                                     previous=graph.modules if graph else None)
    except RuntimeError as e:
        print(f"\n{e}")
        return
    graph, index = Graph.build(modules, meta), None
    graph.save(config.GRAPH_FILE)
    st = graph.stats()
    print(f"\nГотово: модулей {st['modules']}, процедур {st['procs']}, связей {st['edges']} ({st['engine']})")
    if meta["note"]:
        print(meta["note"])


class PrintJob(Job):
    def update(self, **kw):
        super().update(**kw)
        if "done" in kw:
            print(f"\rОписания: {self.state['done']}/{self.state['total']}", end="", flush=True)


def do_describe() -> None:
    if not graph:
        print("Сначала разберите конфигурацию: /parse")
        return
    global index
    try:
        summarize_all(PrintJob(), graph, summaries)
    except Exception as e:
        print(f"\nОшибка: {e}")
    index = None  # описания попадут в поиск
    print("\nГотово")


def answer(question: str) -> None:
    global index
    if not graph:
        print("Сначала разберите конфигурацию: /parse")
        return
    index = index or SearchIndex(graph, summaries)
    r = route(graph, question, index)
    if r["mode"] == "module":
        n = len(r["modules"])
        context = "\n\n".join(build_context(graph, m, summaries, r["focus"] if i == 0 else (), config.CONTEXT_CHARS // n)
                              for i, m in enumerate(r["modules"]))
        print("[модуль: " + ", ".join(r["modules"]) + "]")
    elif r["mode"] == "search":
        context = build_search_context(graph, r["hits"], summaries)
        print("[найдено: " + ", ".join(f"{graph.procs[n]['module']}.{graph.procs[n]['name']}" for n, _ in r["hits"][:5]) + "]")
    else:
        context = build_overview(graph)
        print("[общий обзор конфигурации]")
    try:
        for piece in llm.chat_stream(llm.qa_messages(question, context, [], r["mode"])):
            print(piece, end="", flush=True)
    except Exception as e:
        print(f"\nМодель недоступна: {e}")
    print()


def chat() -> None:
    if not graph:
        print("Конфигурация ещё не разобрана.")
        do_parse()
    print("Задайте вопрос. Команды: /parse [папка], /describe, /exit")
    while True:
        try:
            line = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not line:
            continue
        cmd, _, arg = line.partition(" ")
        if cmd in ("/exit", "/quit"):
            return
        elif cmd == "/parse":
            do_parse(arg.strip() or None)
        elif cmd == "/describe":
            do_describe()
        else:
            answer(line)


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        chat()
    elif args[0] == "parse":
        do_parse(args[1] if len(args) > 1 else None)
    elif args[0] == "describe":
        do_describe()
    elif args[0] == "ask" and len(args) > 1:
        answer(" ".join(args[1:]))
    else:
        print(__doc__)
