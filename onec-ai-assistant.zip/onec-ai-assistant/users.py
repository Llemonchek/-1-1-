"""Управление пользователями веб-приложения.

  python users.py add <имя> lead     создать (или изменить) главного программиста, спросит пароль
  python users.py add <имя> user     создать обычного пользователя (только вопросы)
  python users.py remove <имя>       удалить
  python users.py list               показать всех

Гости без учётной записи тоже могут задавать вопросы (если не включён REQUIRE_LOGIN=1),
отмечать ответы может только пользователь с ролью lead.
"""
import getpass
import sys

from app import auth


def main(args: list[str]) -> None:
    if args[:1] == ["add"] and len(args) == 3:
        password = getpass.getpass("Пароль: ")
        if password != getpass.getpass("Повторите пароль: "):
            sys.exit("Пароли не совпали")
        try:
            auth.add_user(args[1], args[2], password)
        except ValueError as e:
            sys.exit(str(e))
        print(f"Готово: {args[1]} ({auth.ROLE_TITLES[args[2]]})")
    elif args[:1] == ["remove"] and len(args) == 2:
        print("Удалён" if auth.remove_user(args[1]) else "Такого пользователя нет")
    elif args[:1] == ["list"]:
        users = auth.load_users()
        for name, u in users.items():
            print(f"{name}: {auth.ROLE_TITLES[u['role']]}")
        if not users:
            print("Пользователей нет. Создайте главного программиста: python users.py add <имя> lead")
    else:
        print(__doc__)


if __name__ == "__main__":
    main(sys.argv[1:])
